package plant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlantApplicationTests {

    @Test
    void contextLoads() {
    }

}
