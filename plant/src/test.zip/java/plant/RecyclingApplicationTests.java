package plant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecyclingApplicationTests {

    @Test
    void contextLoads() {
    }

}
